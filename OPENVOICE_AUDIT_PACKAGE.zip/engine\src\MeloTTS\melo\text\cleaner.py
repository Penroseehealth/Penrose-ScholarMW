import importlib

from . import english
from . import cleaned_text_to_sequence
import copy

# Local patch: upstream imports every language front-end eagerly, so merely
# loading the English TTS required mecab-python3 (no Windows wheels) and gruut.
# Import the others opportunistically and register only the ones that loaded, so
# an English-only deployment works and a non-English language fails loudly with
# the real reason at use time instead of at import time.
language_module_map = {"EN": english}
for _key, _mod in (
    ("ZH", "chinese"), ("JP", "japanese"), ("ZH_MIX_EN", "chinese_mix"),
    ("KR", "korean"), ("FR", "french"), ("SP", "spanish"), ("ES", "spanish"),
):
    try:
        language_module_map[_key] = importlib.import_module(f".{_mod}", __package__)
    except ImportError:
        pass


def clean_text(text, language):
    language_module = language_module_map[language]
    norm_text = language_module.text_normalize(text)
    phones, tones, word2ph = language_module.g2p(norm_text)
    return norm_text, phones, tones, word2ph


def clean_text_bert(text, language, device=None):
    language_module = language_module_map[language]
    norm_text = language_module.text_normalize(text)
    phones, tones, word2ph = language_module.g2p(norm_text)
    
    word2ph_bak = copy.deepcopy(word2ph)
    for i in range(len(word2ph)):
        word2ph[i] = word2ph[i] * 2
    word2ph[0] += 1
    bert = language_module.get_bert_feature(norm_text, word2ph, device=device)
    
    return norm_text, phones, tones, word2ph_bak, bert


def text_to_sequence(text, language):
    norm_text, phones, tones, word2ph = clean_text(text, language)
    return cleaned_text_to_sequence(phones, tones, language)


if __name__ == "__main__":
    pass